﻿using HtmlAgilityPack;
using SimpleCRMTestDAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace SimpleCRMTest.Controllers
{
    public class SimpleContentApiController : ApiController
    {
        private readonly SimpleCRMTestDAL.SimpleContentDA _simpleContentDB = new SimpleCRMTestDAL.SimpleContentDA();

        [HttpGet]
        public SimpleContent[] GetList()
        {
            var results = _simpleContentDB.GetAll();

            for (var i = 0; i <= results.Count()-1; i++ )
            {
                results[i].HTMLContent = HttpUtility.HtmlDecode(results[i].HTMLContent);
            }

            return results;
        }

        private bool isValidHTML(string htmlContent)
        {
            HtmlDocument doc = new HtmlDocument();
            doc.LoadHtml(htmlContent);
            return (doc.ParseErrors.Count() == 0); // obviously could return full list of errors as well as other validation here with more time
        }

        [HttpPost]
        public string Post(SimpleContent simpleContent)
        {
            if (!this.isValidHTML(simpleContent.HTMLContent))
            {
                return "Save Simple Content Failure: HTML Content is Invalid";
            }

            simpleContent.HTMLContent = HttpUtility.HtmlEncode(simpleContent.HTMLContent); 

            _simpleContentDB.SaveRecord(simpleContent);

            return "Success";
        }
    }
}
