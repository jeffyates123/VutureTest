﻿simpleContentModule.controller("simpleContentController", function ($scope, $routeParams, simpleContentFactory, $sce) {

    $scope.init = function () {
        var urlAccessed = $routeParams.urlAccessed;

        $scope.simpleContent = $scope.getSimpleContent(urlAccessed);

        $scope.trustedHtmlContent = $sce.trustAsHtml($scope.simpleContent.htmlContent);
    }
});