﻿simpleContentModule.factory('simpleContentFactory', function ($http, $q) {
    return {
        getList: function () {
            var deferred = $q.defer();
            $http.get('/SimpleCRMTest/api/SimpleContentApi/GetList').success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        },
        save: function (simpleContent) {
            var deferred = $q.defer();
            $http.post('/SimpleCRMTest/api/SimpleContentApi/Save', JSON.stringify(simpleContent),
            {
                headers: {
                    'Content-Type': 'application/json'
                }
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
    }
});