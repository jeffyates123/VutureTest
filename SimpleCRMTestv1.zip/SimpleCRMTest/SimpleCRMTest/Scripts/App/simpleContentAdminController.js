﻿simpleContentModule.controller("simpleContentAdminController", function ($scope, $routeParams, simpleContentFactory) {

    $scope.lhsColWidth = "col-md-7";
    $scope.rhsColWidth = "col-md-5";

    $scope.ngInit = function () {
        $scope.getContentList();
        $scope.passwordEntered = false;
        $scope.validationFailureMsg = "aaa";

        var password = prompt("Enter the password"); // better ways to do this and not secure obviously! Deadline to be hit.
        if (password == "Welcome") { 
            $scope.passwordEntered = true;
            $("#adminPanel").show();
        } else {
            $scope.passwordEntered = false;
            $("#adminPanel").hide();
        }
    }

    $scope.selectContentToEdit = function (urlAccessed) {
        $scope.selectedSimpleContent = $scope.getSimpleContent(urlAccessed);
        $scope.showValidationMsg = false;
        $scope.allowUrlChange = false;
    }

    $scope.saveSimpleContent = function () {
        $scope.showValidationMsg = true;

        $scope.showSimpleContentSuccess = false;
        $scope.showSimpleContentFailure = true;

        if ($scope.simpleContentForm.$valid) {

            simpleContentFactory.save($scope.selectedSimpleContent).then(function (result) {
                if (result.indexOf("Fail") == -1) {
                    $scope.getContentList();
                    $scope.showSimpleContentSuccess = true;
                    $scope.showSimpleContentFailure = false;
                }
            });
        } else {
        }
    }

    $scope.newSimpleContent = function () {
        $scope.selectedSimpleContent = {urlAccessed:'', title:'', htmlContent:''};
        $scope.showValidationMsg = false;
        $scope.allowUrlChange = true;
    }

});