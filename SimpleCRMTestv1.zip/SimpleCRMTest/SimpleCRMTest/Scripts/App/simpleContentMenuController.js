﻿simpleContentModule.controller("simpleContentMenuController", function ($scope, $routeParams, simpleContentFactory) {

    $scope.ngInit = function () {
        $scope.getContentList();
        $scope.passwordEntered = false;
    }

    $scope.getContentList = function () {
        simpleContentFactory.getList().then(function (simpleContentList) {
            $scope.simpleContentList = simpleContentList;
        });
    }

    $scope.getSimpleContent = function (urlAccessed) {
        var simpleContentFound = false;
        var rtnSimpleContent = null;

        angular.forEach($scope.simpleContentList, function (simpleContent, index) {
            if (simpleContent.urlAccessed == urlAccessed && !simpleContentFound) {
                rtnSimpleContent = simpleContent;
                simpleContentFound = true;
            }
        });

        return rtnSimpleContent;
    }

});