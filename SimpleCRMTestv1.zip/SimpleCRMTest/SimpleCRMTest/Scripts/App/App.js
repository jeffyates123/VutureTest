﻿var simpleContentModule = angular.module('simpleContentModule', ['ngRoute', 'ui.bootstrap'])
    .config(function ($routeProvider, $locationProvider) {
        $routeProvider
        .when('/SimpleCRMTest/Content/:urlAccessed', {
            controller: 'simpleContentController',
            templateUrl: '/SimpleCRMTest/Templates/simpleContentTemplate.html'
        })
        .when('/SimpleCRMTest/Admin', {
            controller: 'simpleContentAdminController',
            templateUrl: '/SimpleCRMTest/Templates/simpleContentAdmin1Template.html'
        })
        .otherwise({
            redirectTo: '/SimpleCRMTest/'
        });
        // use the HTML5 History API
        $locationProvider.html5Mode(true);
    });
