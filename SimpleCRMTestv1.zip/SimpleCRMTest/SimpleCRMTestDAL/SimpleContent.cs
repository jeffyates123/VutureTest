namespace SimpleCRMTestDAL
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("SimpleContent")]
    public partial class SimpleContent
    {
        [Key]
        [StringLength(25)]
        public string UrlAccessed { get; set; }

        [Required]
        [StringLength(50)]
        public string Title { get; set; }

        [Required]
        public string HTMLContent { get; set; }
    }
}
