﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleCRMTestDAL
{
    //public interface ISimpleContentDA
    //{
    //    SimpleContent[] GetAll(); // etc...could use interfaces here if we want to use TDD
    //}

    [NotMapped]
    public class SimpleContentDA 
    {
        VutureDbModel _db = new VutureDbModel();

        public SimpleContent[] GetAll()
        {
            IQueryable<SimpleContent> query = _db.SimpleContent;
            return query.ToArray();
        }

        public void SaveRecord(SimpleContent simpleContent) {
            var existingRecord = this.GetByAccessedUrl(simpleContent.UrlAccessed);

            if (existingRecord != null) {
                existingRecord.Title = simpleContent.Title;
                existingRecord.HTMLContent = simpleContent.HTMLContent;
            } else {
                this.Insert(simpleContent);
            }
            _db.SaveChanges();
        }

        public virtual SimpleContent GetByAccessedUrl(string accessedUrl)
        {
            return _db.SimpleContent.FirstOrDefault(x => x.UrlAccessed == accessedUrl);
        }

        public virtual void Insert(SimpleContent simpleContent)
        {
            var result = _db.SimpleContent.Add(simpleContent);
        }

    }
}
